------------------------------------------------------------------------------------------
Gerber File Extension Report For: agripino.GBR   2016-07-05  1:44:12 AM
------------------------------------------------------------------------------------------


------------------------------------------------------------------------------------------
Layer Extension     Layer Description      NOTES                
------------------------------------------------------------------------------------------
.GTL                Component Side                          
.GP1                Ground Plane           Negative Layer                 
.GP2                Power Plane            Negative Layer                 
.GBL                Solder Side                             
.GTO                Top Overlay                             
.GTS                Top Solder                              
.GBS                Bottom Solder                           
.GM1                Mechanical 1           Board Outline                 
.GD1                Drill Drawing                           
.GG1                Drill Guide                             
------------------------------------------------------------------------------------------

LAYER STACK (top to bottom):

COMPONENT
GROUND PLANE
POWER PLANE
SOLDER

------------------------------------------------------------------------------------------
Please note that gerbers for internal planes are in negative format
------------------------------------------------------------------------------------------
